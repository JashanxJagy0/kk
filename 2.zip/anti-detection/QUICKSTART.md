# Anti-Detection System - Quick Start Guide

## 🚀 Get Started in 3 Steps

### Step 1: Enable Anti-Detection

Edit `properties.conf` in the root directory:

```bash
# Find this line and set it to true
ENABLE_ANTI_DETECTION=true
```

### Step 2: (Optional) Customize Configuration

Edit `anti-detection/configs/anti-detection.conf` to customize:

```bash
# Enable the system
ENABLE_ANTI_DETECTION=true

# Choose target OS to mimic
TARGET_OS="windows"  # options: windows, macos, linux

# Configure fake hardware (use realistic values)
FAKE_HARDWARE_CONCURRENCY=4  # CPU cores (4-8 typical)
FAKE_DEVICE_MEMORY=8         # RAM in GB (8-16 typical)

# Screen resolution (use common resolutions)
FAKE_SCREEN_WIDTH=1920
FAKE_SCREEN_HEIGHT=1080
```

### Step 3: Run Your Script

The anti-detection system will automatically initialize:

```bash
sudo bash internetIncome.sh --start
```

That's it! The anti-detection system will:
- ✅ Configure your network to mimic Windows
- ✅ Hide Docker container indicators
- ✅ Sync timezone with your IP location
- ✅ Generate browser fingerprint scripts
- ✅ Apply all protections to your containers

## 📊 What Gets Applied

When enabled, the anti-detection system protects against:

| Detection Method | Protection Applied | Effectiveness |
|-----------------|-------------------|---------------|
| TCP/IP Fingerprinting | TTL set to 128, Windows TCP stack | 🟢 95% effective |
| Docker Detection | `.dockerenv` hidden, cgroups masked | 🟡 80% effective |
| Browser Fingerprinting | Hardware/Canvas/WebGL spoofed | 🟢 90% effective |
| IP Reputation | Timezone/Location matched | 🟡 Depends on proxy |
| Geolocation Mismatch | Auto-synced to IP location | 🟢 95% effective |

## ⚠️ Important Notes

### 1. Use with Residential Proxies
For best results, use residential proxies. VPS IPs are easily detected regardless of anti-detection measures.

### 2. Root Permissions Required
Some features require root access. Run with `sudo` for full functionality:
```bash
sudo bash internetIncome.sh --start
```

### 3. Test Your Setup
After enabling, test your configuration at:
- https://whoer.net/
- https://browserleaks.com/
- https://amiunique.org/

## 🔍 Verify It's Working

Check if anti-detection is active:

```bash
# Check TCP settings (should show TTL=128 for Windows)
sysctl net.ipv4.ip_default_ttl

# Check timezone (should match your IP location)
date

# Check if Docker flags are loaded
echo $DOCKER_ANTI_DETECTION_FLAGS
```

## 🐛 Troubleshooting

### Anti-Detection Not Running?

1. **Check if enabled in properties.conf**
   ```bash
   grep ENABLE_ANTI_DETECTION properties.conf
   ```
   Should show: `ENABLE_ANTI_DETECTION=true`

2. **Check if directory exists**
   ```bash
   ls -la anti-detection/
   ```

3. **Run manually to see errors**
   ```bash
   sudo ./anti-detection/anti-detection.sh
   ```

### Permission Denied?

Run with sudo:
```bash
sudo bash internetIncome.sh --start
```

### Not Sure If It's Working?

Enable debug mode in `anti-detection/configs/anti-detection.conf`:
```bash
DEBUG_MODE=true
```

Then run again and check output.

## 📚 Learn More

- **Full Documentation**: See `anti-detection/README.md`
- **Integration Guide**: See `anti-detection/INTEGRATION.md` (auto-generated)
- **Browser Setup**: See `anti-detection/browser-scripts/USAGE.md` (auto-generated)

## 💡 Tips for Best Results

1. ✅ **Always use residential proxies** - This is the #1 factor
2. ✅ **Keep fingerprint consistent** - Don't change hardware config frequently
3. ✅ **Match timezone to proxy** - Auto-detection handles this
4. ✅ **Test regularly** - Detection methods evolve
5. ✅ **Monitor logs** - Watch for warnings

## 🎯 Expected Detection Rates

Without Anti-Detection:
- 🔴 **90-95%** detection rate

With Anti-Detection + VPS IP:
- 🟡 **30-40%** detection rate

With Anti-Detection + Residential Proxy:
- 🟢 **5-10%** detection rate

## 🆘 Need Help?

1. Read the full documentation: `anti-detection/README.md`
2. Check troubleshooting section
3. Enable DEBUG_MODE for detailed logs
4. Review generated config files in `anti-detection/configs/`

---

**Ready to Start?** Just set `ENABLE_ANTI_DETECTION=true` in `properties.conf` and run your script! 🚀
