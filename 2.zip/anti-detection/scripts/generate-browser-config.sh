#!/bin/bash

################################################################################
# Browser Fingerprint Configuration Generator
# Purpose: Generate browser fingerprint spoofing script with configuration
################################################################################

# Colors for output
RED="\033[0;31m"
GREEN="\033[0;32m"
YELLOW="\033[0;33m"
NOCOLOUR="\033[0m"

# Load configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="$SCRIPT_DIR/../configs/anti-detection.conf"

if [ -f "$CONFIG_FILE" ]; then
    source "$CONFIG_FILE"
else
    echo -e "${RED}Configuration file not found: $CONFIG_FILE${NOCOLOUR}"
    exit 1
fi

if [ "$ENABLE_ANTI_DETECTION" != "true" ]; then
    echo -e "${YELLOW}Anti-detection system is disabled in configuration${NOCOLOUR}"
    exit 0
fi

echo -e "${GREEN}=== Generating Browser Fingerprint Configuration ===${NOCOLOUR}"

# Output file
OUTPUT_FILE="$SCRIPT_DIR/../browser-scripts/fingerprint-spoof-configured.js"

# Read the template
TEMPLATE_FILE="$SCRIPT_DIR/../browser-scripts/fingerprint-spoof.js"

if [ ! -f "$TEMPLATE_FILE" ]; then
    echo -e "${RED}Template file not found: $TEMPLATE_FILE${NOCOLOUR}"
    exit 1
fi

# Create configured version
cp "$TEMPLATE_FILE" "$OUTPUT_FILE"

# Replace configuration values using sed
sed -i "s/hardwareConcurrency: 4/hardwareConcurrency: $FAKE_HARDWARE_CONCURRENCY/g" "$OUTPUT_FILE"
sed -i "s/deviceMemory: 8/deviceMemory: $FAKE_DEVICE_MEMORY/g" "$OUTPUT_FILE"
sed -i "s/maxTouchPoints: 0/maxTouchPoints: $FAKE_MAX_TOUCH_POINTS/g" "$OUTPUT_FILE"
sed -i "s/platform: \"Win32\"/platform: \"$FAKE_PLATFORM\"/g" "$OUTPUT_FILE"
sed -i "s/screenWidth: 1920/screenWidth: $FAKE_SCREEN_WIDTH/g" "$OUTPUT_FILE"
sed -i "s/screenHeight: 1080/screenHeight: $FAKE_SCREEN_HEIGHT/g" "$OUTPUT_FILE"
sed -i "s/colorDepth: 24/colorDepth: $FAKE_COLOR_DEPTH/g" "$OUTPUT_FILE"
sed -i "s/pixelRatio: 1/pixelRatio: $FAKE_PIXEL_RATIO/g" "$OUTPUT_FILE"

# Boolean values
sed -i "s/enableCanvasNoise: true/enableCanvasNoise: $(echo $ENABLE_CANVAS_NOISE | tr '[:upper:]' '[:lower:]')/g" "$OUTPUT_FILE"
sed -i "s/enableWebGLSpoofing: true/enableWebGLSpoofing: $(echo $ENABLE_WEBGL_SPOOFING | tr '[:upper:]' '[:lower:]')/g" "$OUTPUT_FILE"
sed -i "s/maskWebRTC: true/maskWebRTC: $(echo $MASK_WEBRTC_IP | tr '[:upper:]' '[:lower:]')/g" "$OUTPUT_FILE"

# Battery
if [ "$ENABLE_BATTERY_SPOOFING" = "true" ]; then
    sed -i "s/batteryCharging: true/batteryCharging: $(echo $FAKE_BATTERY_CHARGING | tr '[:upper:]' '[:lower:]')/g" "$OUTPUT_FILE"
    sed -i "s/batteryLevel: 0.85/batteryLevel: $FAKE_BATTERY_LEVEL/g" "$OUTPUT_FILE"
fi

# User Agent (escape special characters)
ESCAPED_UA=$(echo "$FAKE_USER_AGENT" | sed 's/[\/&]/\\&/g')
sed -i "s/userAgent: \"Mozilla\/5.0.*/userAgent: \"$ESCAPED_UA\",/g" "$OUTPUT_FILE"

# WebGL
if [ -n "$WEBGL_VENDOR" ]; then
    ESCAPED_VENDOR=$(echo "$WEBGL_VENDOR" | sed 's/[\/&]/\\&/g')
    sed -i "s/webglVendor: \"Google.*/webglVendor: \"$ESCAPED_VENDOR\",/g" "$OUTPUT_FILE"
fi

if [ -n "$WEBGL_RENDERER" ]; then
    ESCAPED_RENDERER=$(echo "$WEBGL_RENDERER" | sed 's/[\/&]/\\&/g')
    sed -i "s/webglRenderer: \"ANGLE.*/webglRenderer: \"$ESCAPED_RENDERER\",/g" "$OUTPUT_FILE"
fi

# Languages
if [ -n "$FAKE_LANGUAGES" ]; then
    # Convert comma-separated to JSON array format
    LANGS_JSON=$(echo "$FAKE_LANGUAGES" | awk -F',' '{printf "["; for(i=1;i<=NF;i++){printf "\"%s\"", $i; if(i<NF)printf ", "} printf "]"}')
    sed -i "s/languages: \[\"en-US\", \"en\"\]/languages: $LANGS_JSON/g" "$OUTPUT_FILE"
fi

echo -e "${GREEN}✓ Generated configured browser script: $OUTPUT_FILE${NOCOLOUR}"

# Generate usage instructions
cat > "$SCRIPT_DIR/../browser-scripts/USAGE.md" << 'EOF'
# Browser Fingerprint Spoofing - Usage Instructions

## Chrome/Chromium with CDP (Chrome DevTools Protocol)

Use the `--enable-features=NetworkService` flag and inject the script using CDP:

```bash
chrome \
  --enable-features=NetworkService \
  --remote-debugging-port=9222 \
  --user-data-dir=/path/to/profile
```

Then use a CDP client to inject `fingerprint-spoof-configured.js`.

## Firefox with about:config

1. Open Firefox
2. Navigate to `about:config`
3. Set `privacy.resistFingerprinting` to `true`
4. Install a user script manager like Greasemonkey or Tampermonkey
5. Add the `fingerprint-spoof-configured.js` as a user script

## Docker Container Integration

### Option 1: Chrome/Chromium in Docker
```dockerfile
# Add to your Dockerfile
COPY anti-detection/browser-scripts/fingerprint-spoof-configured.js /app/fingerprint-spoof.js

# Run Chrome with CDP
CMD ["chromium-browser", \
     "--remote-debugging-port=9222", \
     "--user-data-dir=/data/chrome-profile", \
     "--no-sandbox", \
     "--disable-dev-shm-usage"]
```

Then inject the script via CDP using a Node.js script or puppeteer.

### Option 2: Browser Extension
1. Create a browser extension that injects this script
2. Load the extension in your Docker container's browser

### Option 3: Proxy Injection
Use a local proxy that injects the script into every HTML page:
```javascript
// In your proxy server
if (contentType === 'text/html') {
    const script = fs.readFileSync('fingerprint-spoof-configured.js');
    body = body.replace('<head>', `<head><script>${script}</script>`);
}
```

## Puppeteer/Playwright Integration

```javascript
const puppeteer = require('puppeteer');
const fs = require('fs');

const fingerprintScript = fs.readFileSync('fingerprint-spoof-configured.js', 'utf8');

const browser = await puppeteer.launch();
const page = await browser.newPage();

// Inject on every page load
await page.evaluateOnNewDocument(fingerprintScript);

await page.goto('https://example.com');
```

## Testing Your Configuration

Visit these sites to test your fingerprint:
- https://browserleaks.com/canvas
- https://browserleaks.com/webgl
- https://whoer.net/
- https://amiunique.org/
- https://coveryourtracks.eff.org/

Make sure your fingerprint matches a typical Windows/Mac desktop user.
EOF

echo -e "${GREEN}✓ Generated usage documentation${NOCOLOUR}"

echo -e "${GREEN}=== Browser Configuration Complete ===${NOCOLOUR}"
echo -e "${YELLOW}The configured script is available at: $OUTPUT_FILE${NOCOLOUR}"
echo -e "${YELLOW}See browser-scripts/USAGE.md for integration instructions${NOCOLOUR}"
