#!/bin/bash

################################################################################
# Timezone and Geolocation Synchronization Script
# Purpose: Automatically detect and set timezone based on proxy IP location
# This prevents detection through timezone/location mismatches
################################################################################

# Colors for output
RED="\033[0;31m"
GREEN="\033[0;32m"
YELLOW="\033[0;33m"
NOCOLOUR="\033[0m"

# Load configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="$SCRIPT_DIR/../configs/anti-detection.conf"

if [ -f "$CONFIG_FILE" ]; then
    source "$CONFIG_FILE"
else
    echo -e "${RED}Configuration file not found: $CONFIG_FILE${NOCOLOUR}"
    exit 1
fi

if [ "$ENABLE_ANTI_DETECTION" != "true" ]; then
    echo -e "${YELLOW}Anti-detection system is disabled in configuration${NOCOLOUR}"
    exit 0
fi

echo -e "${GREEN}=== Timezone and Geolocation Synchronization ===${NOCOLOUR}"

# Function to get public IP
get_public_ip() {
    local ip=""
    
    # Try multiple services
    ip=$(curl -s -m 5 https://api.ipify.org 2>/dev/null)
    if [ -z "$ip" ]; then
        ip=$(curl -s -m 5 https://ifconfig.me 2>/dev/null)
    fi
    if [ -z "$ip" ]; then
        ip=$(curl -s -m 5 https://icanhazip.com 2>/dev/null)
    fi
    
    echo "$ip"
}

# Function to get geolocation from IP
get_geolocation() {
    local ip=$1
    
    if [ -z "$ip" ]; then
        echo -e "${RED}No IP provided${NOCOLOUR}"
        return 1
    fi
    
    echo -e "${GREEN}Fetching geolocation for IP: $ip${NOCOLOUR}"
    
    # Use ip-api.com (free, no key required)
    local response=$(curl -s -m 10 "http://ip-api.com/json/$ip")
    
    if [ -z "$response" ]; then
        echo -e "${RED}Failed to fetch geolocation data${NOCOLOUR}"
        return 1
    fi
    
    # Parse JSON response
    local status=$(echo "$response" | grep -o '"status":"[^"]*"' | cut -d'"' -f4)
    
    if [ "$status" != "success" ]; then
        echo -e "${RED}Geolocation API returned error${NOCOLOUR}"
        return 1
    fi
    
    # Extract data
    local timezone=$(echo "$response" | grep -o '"timezone":"[^"]*"' | cut -d'"' -f4)
    local country=$(echo "$response" | grep -o '"country":"[^"]*"' | cut -d'"' -f4)
    local city=$(echo "$response" | grep -o '"city":"[^"]*"' | cut -d'"' -f4)
    local lat=$(echo "$response" | grep -o '"lat":[0-9.-]*' | cut -d':' -f2)
    local lon=$(echo "$response" | grep -o '"lon":[0-9.-]*' | cut -d':' -f2)
    local isp=$(echo "$response" | grep -o '"isp":"[^"]*"' | cut -d'"' -f4)
    local asn=$(echo "$response" | grep -o '"as":"[^"]*"' | cut -d'"' -f4)
    
    echo -e "${GREEN}Location: $city, $country${NOCOLOUR}"
    echo -e "${GREEN}Timezone: $timezone${NOCOLOUR}"
    echo -e "${GREEN}ISP: $isp${NOCOLOUR}"
    echo -e "${GREEN}ASN: $asn${NOCOLOUR}"
    echo -e "${GREEN}Coordinates: $lat, $lon${NOCOLOUR}"
    
    # Check if it's a data center IP
    if echo "$isp" | grep -iE "hosting|datacenter|cloud|digital ocean|aws|google cloud|azure|linode|vultr|hetzner" > /dev/null; then
        echo -e "${RED}⚠ WARNING: This appears to be a data center IP!${NOCOLOUR}"
        echo -e "${RED}  Detection risk is HIGH. Consider using residential proxies.${NOCOLOUR}"
    else
        echo -e "${GREEN}✓ IP appears to be residential or ISP${NOCOLOUR}"
    fi
    
    # Export variables
    export DETECTED_TIMEZONE="$timezone"
    export DETECTED_COUNTRY="$country"
    export DETECTED_CITY="$city"
    export DETECTED_LAT="$lat"
    export DETECTED_LON="$lon"
    
    return 0
}

# Function to set system timezone
set_system_timezone() {
    local timezone=$1
    
    if [ -z "$timezone" ]; then
        echo -e "${RED}No timezone provided${NOCOLOUR}"
        return 1
    fi
    
    echo -e "${GREEN}Setting system timezone to: $timezone${NOCOLOUR}"
    
    # Check if timezone is valid
    if [ ! -f "/usr/share/zoneinfo/$timezone" ]; then
        echo -e "${RED}Invalid timezone: $timezone${NOCOLOUR}"
        return 1
    fi
    
    # Try to set timezone
    if [ "$EUID" -eq 0 ] || sudo -n true 2>/dev/null; then
        # Method 1: Using timedatectl (systemd)
        if command -v timedatectl &> /dev/null; then
            if timedatectl set-timezone "$timezone" 2>/dev/null || sudo timedatectl set-timezone "$timezone" 2>/dev/null; then
                echo -e "${GREEN}✓ Timezone set using timedatectl${NOCOLOUR}"
                return 0
            fi
        fi
        
        # Method 2: Using ln -sf
        if ln -sf "/usr/share/zoneinfo/$timezone" /etc/localtime 2>/dev/null || sudo ln -sf "/usr/share/zoneinfo/$timezone" /etc/localtime 2>/dev/null; then
            echo -e "${GREEN}✓ Timezone set using symlink${NOCOLOUR}"
            
            # Also update /etc/timezone if it exists
            if echo "$timezone" > /etc/timezone 2>/dev/null || echo "$timezone" | sudo tee /etc/timezone > /dev/null 2>&1; then
                echo -e "${GREEN}✓ Updated /etc/timezone${NOCOLOUR}"
            fi
            
            return 0
        fi
    else
        echo -e "${YELLOW}⚠ Cannot set system timezone (need root). Setting TZ environment variable instead.${NOCOLOUR}"
        export TZ="$timezone"
        echo "export TZ='$timezone'" >> ~/.bashrc
        echo -e "${GREEN}✓ TZ environment variable set${NOCOLOUR}"
        return 0
    fi
    
    echo -e "${RED}Failed to set timezone${NOCOLOUR}"
    return 1
}

# Main logic
if [ "$AUTO_DETECT_TIMEZONE" = "true" ]; then
    echo -e "${GREEN}Auto-detecting timezone from IP...${NOCOLOUR}"
    
    # Get public IP
    PUBLIC_IP=$(get_public_ip)
    
    if [ -z "$PUBLIC_IP" ]; then
        echo -e "${RED}Failed to detect public IP${NOCOLOUR}"
        echo -e "${YELLOW}Make sure you have internet connectivity${NOCOLOUR}"
        exit 1
    fi
    
    echo -e "${GREEN}Public IP: $PUBLIC_IP${NOCOLOUR}"
    
    # Get geolocation
    if get_geolocation "$PUBLIC_IP"; then
        # Set timezone
        if [ -n "$DETECTED_TIMEZONE" ]; then
            set_system_timezone "$DETECTED_TIMEZONE"
        fi
        
        # Save geolocation data
        GEO_FILE="$SCRIPT_DIR/../configs/geolocation.json"
        cat > "$GEO_FILE" << EOF
{
  "ip": "$PUBLIC_IP",
  "timezone": "$DETECTED_TIMEZONE",
  "country": "$DETECTED_COUNTRY",
  "city": "$DETECTED_CITY",
  "latitude": "$DETECTED_LAT",
  "longitude": "$DETECTED_LON",
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
EOF
        echo -e "${GREEN}✓ Geolocation data saved to: $GEO_FILE${NOCOLOUR}"
    else
        echo -e "${RED}Failed to fetch geolocation${NOCOLOUR}"
        exit 1
    fi
else
    echo -e "${YELLOW}Auto-detection disabled. Using manual timezone.${NOCOLOUR}"
    
    if [ -n "$MANUAL_TIMEZONE" ]; then
        set_system_timezone "$MANUAL_TIMEZONE"
    else
        echo -e "${RED}No manual timezone configured${NOCOLOUR}"
        exit 1
    fi
fi

echo -e "${GREEN}=== Timezone Synchronization Complete ===${NOCOLOUR}"

# Display current timezone
echo -e "${YELLOW}Current system time:${NOCOLOUR}"
date

if [ "$DEBUG_MODE" = "true" ]; then
    echo -e "${YELLOW}Debug: Timezone info:${NOCOLOUR}"
    if command -v timedatectl &> /dev/null; then
        timedatectl
    else
        echo "TZ=$TZ"
        echo "Date: $(date)"
    fi
fi
