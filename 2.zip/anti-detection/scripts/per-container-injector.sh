#!/bin/bash

# Per-Container Anti-Detection Injector
# Applies unique fingerprint to each container at runtime

apply_container_fingerprint() {
    local container_num=$1
    local identity_file=$2
    
    # Load identity
    source "$identity_file"
    
    # Build Docker runtime parameters with this container's identity
    local runtime_params=""
    
    # CPU limiting
    runtime_params+="--cpus=${CONTAINER_CPU_CORES} "
    
    # Memory limiting
    runtime_params+="--memory=${CONTAINER_RAM_GB}g "
    
    # Security options to hide containerization
    runtime_params+="--security-opt apparmor=unconfined "
    runtime_params+="--cap-add=SYS_ADMIN "
    
    # Generate and mount fake cpuinfo
    local cpuinfo_path=$(/root/kk/anti-detection/scripts/container-identity-forge.sh cpuinfo "$CONTAINER_CPU_CORES" "0x${CONTAINER_ENTROPY_SEED:0:4}")
    if [ -f "$cpuinfo_path" ]; then
        runtime_params+="-v ${cpuinfo_path}:/proc/cpuinfo:ro "
    fi
    
    # Environment variables for browser fingerprinting
    runtime_params+="-e FINGERPRINT_CPU=${CONTAINER_CPU_CORES} "
    runtime_params+="-e FINGERPRINT_RAM=${CONTAINER_RAM_GB} "
    runtime_params+="-e FINGERPRINT_SCREEN_W=${CONTAINER_SCREEN_W} "
    runtime_params+="-e FINGERPRINT_SCREEN_H=${CONTAINER_SCREEN_H} "
    runtime_params+="-e FINGERPRINT_GPU=${CONTAINER_GPU_VENDOR} "
    
    echo "$runtime_params"
}

# Generate browser injection script for this container
generate_browser_script() {
    local identity_file=$1
    local output_file=$2
    
    source "$identity_file"
    
    cat > "$output_file" <<'BROWSER_SCRIPT_START'
(function() {
    var fpData = {
        cpu: parseInt(document.currentScript.getAttribute('data-cpu')),
        ram: parseInt(document.currentScript.getAttribute('data-ram')),
        screenW: parseInt(document.currentScript.getAttribute('data-screen-w')),
        screenH: parseInt(document.currentScript.getAttribute('data-screen-h')),
        gpu: document.currentScript.getAttribute('data-gpu')
    };
    
    Object.defineProperty(navigator, 'hardwareConcurrency', {
        get: function() { return fpData.cpu; }
    });
    
    Object.defineProperty(navigator, 'deviceMemory', {
        get: function() { return fpData.ram; }
    });
    
    Object.defineProperty(screen, 'width', {
        get: function() { return fpData.screenW; }
    });
    
    Object.defineProperty(screen, 'height', {
        get: function() { return fpData.screenH; }
    });
    
    var origGetParameter = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function(param) {
        if (param === 37445) return fpData.gpu + " Inc.";
        if (param === 37446) return "ANGLE (" + fpData.gpu + ")";
        return origGetParameter.call(this, param);
    };
})();
BROWSER_SCRIPT_START

    # Add data attributes line
    echo "// Data: cpu=${CONTAINER_CPU_CORES} ram=${CONTAINER_RAM_GB} screen=${CONTAINER_SCREEN_W}x${CONTAINER_SCREEN_H} gpu=${CONTAINER_GPU_VENDOR}" >> "$output_file"
}

if [ "$1" = "apply" ]; then
    apply_container_fingerprint "$2" "$3"
elif [ "$1" = "browser" ]; then
    generate_browser_script "$2" "$3"
fi
