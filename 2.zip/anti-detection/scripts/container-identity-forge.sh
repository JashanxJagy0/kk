#!/bin/bash

# Container Identity Forge - Generates unique fingerprints per container
# Uses container index and proxy as entropy sources

forge_identity() {
    local container_idx=$1
    local proxy_str=$2
    
    # Create deterministic seed from inputs
    local entropy_seed=$(echo "${container_idx}${proxy_str}" | md5sum | cut -d' ' -f1)
    local seed_num=$((0x${entropy_seed:0:8} % 10000))
    
    # Hardware profiles - varied but realistic
    local cpu_options=(1 1 1 2 2)
    local ram_options=(4 8 8 12 16)
    local width_options=(1366 1920 1920 2560 1440)
    local height_options=(768 1080 1080 1440 900)
    
    # Select based on seed
    local cpu_idx=$((seed_num % ${#cpu_options[@]}))
    local ram_idx=$(((seed_num / 10) % ${#ram_options[@]}))
    local screen_idx=$(((seed_num / 100) % ${#width_options[@]}))
    
    # GPU vendors for realism
    local gpu_vendors=("Intel" "NVIDIA" "AMD")
    local gpu_idx=$(((seed_num / 1000) % ${#gpu_vendors[@]}))
    
    # Build identity data structure
    cat > "/tmp/container_identity_${container_idx}.env" <<IDENTITY_EOF
CONTAINER_CPU_CORES=${cpu_options[$cpu_idx]}
CONTAINER_RAM_GB=${ram_options[$ram_idx]}
CONTAINER_SCREEN_W=${width_options[$screen_idx]}
CONTAINER_SCREEN_H=${height_options[$screen_idx]}
CONTAINER_GPU_VENDOR=${gpu_vendors[$gpu_idx]}
CONTAINER_ENTROPY_SEED=$entropy_seed
CONTAINER_INDEX=$container_idx
IDENTITY_EOF

    echo "/tmp/container_identity_${container_idx}.env"
}

# Generate fake proc info
forge_cpuinfo() {
    local cores=$1
    local model_seed=$2
    
    local cpu_models=(
        "Intel(R) Core(TM) i5-8250U CPU @ 1.60GHz"
        "Intel(R) Core(TM) i7-9750H CPU @ 2.60GHz"
        "AMD Ryzen 5 3600 6-Core Processor"
        "Intel(R) Core(TM) i3-10100 CPU @ 3.60GHz"
    )
    
    local model_idx=$((model_seed % ${#cpu_models[@]}))
    local chosen_model="${cpu_models[$model_idx]}"
    
    local output_file="/tmp/cpuinfo_c${cores}_m${model_idx}"
    
    > "$output_file"
    
    for ((proc=0; proc<cores; proc++)); do
        cat >> "$output_file" <<CPUINFO_BLOCK
processor	: $proc
vendor_id	: GenuineIntel
cpu family	: 6
model		: 158
model name	: $chosen_model
stepping	: 10
cpu MHz		: $((1600 + (model_seed % 2000))).$((model_seed % 1000))
cache size	: $((6144 + (model_seed % 2048))) KB
physical id	: 0
siblings	: $cores
core id		: $proc
cpu cores	: $cores
apicid		: $((proc * 2))
fpu		: yes
flags		: fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush mmx fxsr sse sse2 ht syscall nx rdtscp lm constant_tsc rep_good nopl pni pclmulqdq ssse3 fma cx16 sse4_1 sse4_2 movbe popcnt aes xsave avx f16c rdrand hypervisor lahf_lm abm 3dnowprefetch fsgsbase bmi1 avx2 smep bmi2 erms invpcid rdseed adx smap clflushopt
bogomips	: $((3200 + (model_seed % 1000)))

CPUINFO_BLOCK
    done
    
    echo "$output_file"
}

# Main execution
if [ "$1" = "forge" ]; then
    forge_identity "$2" "$3"
elif [ "$1" = "cpuinfo" ]; then
    forge_cpuinfo "$2" "$3"
fi
