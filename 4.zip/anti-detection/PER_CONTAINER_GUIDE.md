# Per-Container Anti-Detection System

## Overview

This system generates **unique fingerprints for each container**, making every container appear as a different real home PC. Each container gets:

- Unique CPU core count (2-8 cores)
- Unique RAM amount (4-16GB)
- Unique screen resolution (1366x768, 1920x1080, 2560x1440, etc.)
- Unique GPU vendor (Intel, NVIDIA, AMD)
- Unique fake `/proc/cpuinfo` file
- Deterministic but varied profiles

## How It Works

### 1. Identity Generation (`container-identity-forge.sh`)

For each container, generates a unique identity based on:
- Container index number
- Proxy string (ensures different proxies = different fingerprints)

The script uses MD5 hash of these inputs as a seed, ensuring:
- **Deterministic**: Same container + proxy = same fingerprint
- **Unique**: Different containers get different fingerprints
- **Realistic**: Values are within normal PC ranges

### 2. Runtime Injection (`per-container-injector.sh`)

Applies the identity to Docker containers by:
- Generating Docker runtime flags (`--cpus`, `--memory`, etc.)
- Creating fake `/proc/cpuinfo` with matching CPU specs
- Setting environment variables for browser fingerprinting
- Adding security options to hide containerization

### 3. Integration (`internetIncome.sh`)

Modified to:
- Generate identity at container startup
- Apply unique parameters to EVERY docker run command
- Works automatically when `ENABLE_ANTI_DETECTION=true`

## Container Examples

### Container 1 with proxy1
```bash
CPU: 8 cores
RAM: 12GB
Screen: 1440x900
GPU: Intel
```

### Container 2 with proxy2
```bash
CPU: 8 cores
RAM: 16GB
Screen: 1920x1080
GPU: Intel
```

### Container 3 with proxy3
```bash
CPU: 4 cores
RAM: 8GB
Screen: 1920x1080
GPU: AMD
```

Each looks like a completely different PC!

## Usage

1. **Enable in properties.conf:**
   ```bash
   ENABLE_ANTI_DETECTION=true
   ```

2. **Run normally:**
   ```bash
   sudo bash internetIncome.sh --start
   ```

3. **Automatic**: Each container gets unique fingerprint automatically

## Files Created

- `/tmp/container_identity_{N}.env` - Identity file for container N
- `/tmp/cpuinfo_c{cores}_m{model}` - Fake cpuinfo files
- Cached and reused for consistency

## Verification

Check a running container:

```bash
# View assigned resources
docker inspect container_name | grep -A 5 "NanoCpus\|Memory"

# View fake cpuinfo inside container
docker exec container_name cat /proc/cpuinfo

# View fingerprint environment variables
docker exec container_name env | grep FINGERPRINT
```

## Benefits

✅ **Each container = Different PC**: Detection systems see multiple distinct devices
✅ **Realistic Variation**: Hardware combinations match real-world PCs
✅ **Automatic**: No manual configuration needed
✅ **Consistent**: Same container keeps same fingerprint across restarts
✅ **Lightweight**: Minimal overhead, fast generation

## Technical Details

### Hardware Pools

```python
CPU Options: [2, 4, 4, 6, 8]  # Weighted toward common configs
RAM Options: [4, 8, 8, 12, 16]  # GB
Width Options: [1366, 1920, 1920, 2560, 1440]
Height Options: [768, 1080, 1080, 1440, 900]
GPU Vendors: ["Intel", "NVIDIA", "AMD"]
```

### Selection Algorithm

```bash
seed = md5(container_index + proxy_string)
cpu_index = seed % 5
ram_index = (seed / 10) % 5
screen_index = (seed / 100) % 5
gpu_index = (seed / 1000) % 3
```

This ensures even distribution across realistic configurations.

## Troubleshooting

### Issue: All containers have same fingerprint
**Solution**: Verify anti-detection scripts are executable and proxies are different

### Issue: Container fails to start
**Solution**: Check Docker has permissions for security options and memory limits

### Issue: /proc/cpuinfo not mounted
**Solution**: Cpuinfo files are auto-generated, check /tmp directory has write permissions

## Advanced

### Custom Hardware Pools

Edit `container-identity-forge.sh` to modify available hardware options:

```bash
local cpu_options=(2 4 6 8 16)  # Add more variety
local ram_options=(8 16 32)     # Higher-end systems
```

### Manual Identity Testing

```bash
# Generate identity for container 5 with specific proxy
./anti-detection/scripts/container-identity-forge.sh forge 5 "socks5://192.168.1.1:1080"

# View generated identity
cat /tmp/container_identity_5.env

# Get Docker params
./anti-detection/scripts/per-container-injector.sh apply 5 /tmp/container_identity_5.env
```
