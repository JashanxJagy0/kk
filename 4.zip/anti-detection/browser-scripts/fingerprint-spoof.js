/**
 * Browser Fingerprint Spoofing Script
 * This script should be injected into the browser to spoof hardware and environment information
 * Works with Chrome DevTools Protocol (CDP) or browser extensions
 */

(function() {
    'use strict';
    
    // Configuration (will be replaced by the shell script)
    const CONFIG = {
        hardwareConcurrency: 4,
        deviceMemory: 8,
        maxTouchPoints: 0,
        platform: "Win32",
        vendor: "Google Inc.",
        languages: ["en-US", "en"],
        userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        webglVendor: "Google Inc. (Intel)",
        webglRenderer: "ANGLE (Intel, Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0)",
        screenWidth: 1920,
        screenHeight: 1080,
        colorDepth: 24,
        pixelRatio: 1,
        batteryCharging: true,
        batteryLevel: 0.85,
        enableCanvasNoise: true,
        enableWebGLSpoofing: true,
        maskWebRTC: true
    };
    
    console.log("[Anti-Detection] Browser fingerprint spoofing initialized");
    
    // Spoof Navigator Properties
    try {
        Object.defineProperty(navigator, 'hardwareConcurrency', {
            get: () => CONFIG.hardwareConcurrency,
            configurable: true
        });
        
        Object.defineProperty(navigator, 'deviceMemory', {
            get: () => CONFIG.deviceMemory,
            configurable: true
        });
        
        Object.defineProperty(navigator, 'maxTouchPoints', {
            get: () => CONFIG.maxTouchPoints,
            configurable: true
        });
        
        Object.defineProperty(navigator, 'platform', {
            get: () => CONFIG.platform,
            configurable: true
        });
        
        Object.defineProperty(navigator, 'vendor', {
            get: () => CONFIG.vendor,
            configurable: true
        });
        
        Object.defineProperty(navigator, 'languages', {
            get: () => CONFIG.languages,
            configurable: true
        });
        
        Object.defineProperty(navigator, 'userAgent', {
            get: () => CONFIG.userAgent,
            configurable: true
        });
        
        console.log("[Anti-Detection] Navigator properties spoofed");
    } catch (e) {
        console.warn("[Anti-Detection] Could not spoof some navigator properties:", e);
    }
    
    // Spoof Screen Properties
    try {
        Object.defineProperty(screen, 'width', {
            get: () => CONFIG.screenWidth,
            configurable: true
        });
        
        Object.defineProperty(screen, 'height', {
            get: () => CONFIG.screenHeight,
            configurable: true
        });
        
        Object.defineProperty(screen, 'availWidth', {
            get: () => CONFIG.screenWidth,
            configurable: true
        });
        
        Object.defineProperty(screen, 'availHeight', {
            get: () => CONFIG.screenHeight - 40, // Account for taskbar
            configurable: true
        });
        
        Object.defineProperty(screen, 'colorDepth', {
            get: () => CONFIG.colorDepth,
            configurable: true
        });
        
        Object.defineProperty(window, 'devicePixelRatio', {
            get: () => CONFIG.pixelRatio,
            configurable: true
        });
        
        console.log("[Anti-Detection] Screen properties spoofed");
    } catch (e) {
        console.warn("[Anti-Detection] Could not spoof screen properties:", e);
    }
    
    // Spoof Battery API
    if (CONFIG.batteryCharging !== undefined && navigator.getBattery) {
        const originalGetBattery = navigator.getBattery.bind(navigator);
        navigator.getBattery = async function() {
            const battery = await originalGetBattery();
            Object.defineProperty(battery, 'charging', {
                get: () => CONFIG.batteryCharging,
                configurable: true
            });
            Object.defineProperty(battery, 'level', {
                get: () => CONFIG.batteryLevel,
                configurable: true
            });
            return battery;
        };
        console.log("[Anti-Detection] Battery API spoofed");
    }
    
    // Canvas Fingerprinting Protection
    if (CONFIG.enableCanvasNoise) {
        const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
        const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;
        
        // Add noise to canvas
        const addCanvasNoise = (canvas, context) => {
            const imageData = originalGetImageData.call(context, 0, 0, canvas.width, canvas.height);
            const data = imageData.data;
            
            // Add minimal noise to avoid detection
            for (let i = 0; i < data.length; i += 4) {
                const noise = Math.floor(Math.random() * 3) - 1; // -1, 0, or 1
                data[i] = Math.min(255, Math.max(0, data[i] + noise));     // R
                data[i+1] = Math.min(255, Math.max(0, data[i+1] + noise)); // G
                data[i+2] = Math.min(255, Math.max(0, data[i+2] + noise)); // B
            }
            
            context.putImageData(imageData, 0, 0);
        };
        
        HTMLCanvasElement.prototype.toDataURL = function(type) {
            if (this.width > 0 && this.height > 0) {
                const context = this.getContext('2d');
                if (context) {
                    addCanvasNoise(this, context);
                }
            }
            return originalToDataURL.apply(this, arguments);
        };
        
        console.log("[Anti-Detection] Canvas fingerprinting protection enabled");
    }
    
    // WebGL Fingerprinting Protection
    if (CONFIG.enableWebGLSpoofing) {
        const getParameterProxyHandler = {
            apply: function(target, thisArg, args) {
                const param = args[0];
                
                // Spoof WebGL parameters
                if (param === 37445) { // UNMASKED_VENDOR_WEBGL
                    return CONFIG.webglVendor;
                }
                if (param === 37446) { // UNMASKED_RENDERER_WEBGL
                    return CONFIG.webglRenderer;
                }
                
                return target.apply(thisArg, args);
            }
        };
        
        const originalGetParameter = WebGLRenderingContext.prototype.getParameter;
        WebGLRenderingContext.prototype.getParameter = new Proxy(originalGetParameter, getParameterProxyHandler);
        
        if (window.WebGL2RenderingContext) {
            const originalGetParameter2 = WebGL2RenderingContext.prototype.getParameter;
            WebGL2RenderingContext.prototype.getParameter = new Proxy(originalGetParameter2, getParameterProxyHandler);
        }
        
        console.log("[Anti-Detection] WebGL fingerprinting protection enabled");
    }
    
    // WebRTC IP Leak Prevention
    if (CONFIG.maskWebRTC) {
        // Override RTCPeerConnection to prevent IP leaks
        if (window.RTCPeerConnection) {
            const originalRTCPeerConnection = window.RTCPeerConnection;
            
            window.RTCPeerConnection = function(config, constraints) {
                // Modify config to prevent IP leaks
                if (config && config.iceServers) {
                    config.iceServers = [];
                }
                
                return new originalRTCPeerConnection(config, constraints);
            };
            
            // Copy prototype
            window.RTCPeerConnection.prototype = originalRTCPeerConnection.prototype;
            
            console.log("[Anti-Detection] WebRTC IP leak prevention enabled");
        }
    }
    
    // Spoof Media Devices
    if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
        const originalEnumerateDevices = navigator.mediaDevices.enumerateDevices.bind(navigator.mediaDevices);
        
        navigator.mediaDevices.enumerateDevices = async function() {
            // Return fake device list
            return [
                {
                    deviceId: "default",
                    kind: "audioinput",
                    label: "Microphone (Realtek High Definition Audio)",
                    groupId: "abc123"
                },
                {
                    deviceId: "communications",
                    kind: "audiooutput",
                    label: "Speakers (Realtek High Definition Audio)",
                    groupId: "abc123"
                },
                {
                    deviceId: "default",
                    kind: "audiooutput",
                    label: "Speakers (Realtek High Definition Audio)",
                    groupId: "abc123"
                },
                {
                    deviceId: "videoinput",
                    kind: "videoinput",
                    label: "HD WebCam (04f2:b5c3)",
                    groupId: "xyz789"
                }
            ];
        };
        
        console.log("[Anti-Detection] Media devices spoofed");
    }
    
    // Protect against detection of this script
    const originalToString = Function.prototype.toString;
    Function.prototype.toString = function() {
        if (this === navigator.hardwareConcurrency || 
            this === navigator.deviceMemory ||
            this === navigator.platform ||
            this === navigator.languages) {
            return 'function get() { [native code] }';
        }
        return originalToString.call(this);
    };
    
    console.log("[Anti-Detection] Fingerprint spoofing complete");
})();
