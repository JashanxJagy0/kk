#!/bin/bash

################################################################################
# Anti-Detection System Control Script
# Purpose: Easy enable/disable of anti-detection features
################################################################################

# Colors
RED="\033[0;31m"
GREEN="\033[0;32m"
YELLOW="\033[0;33m"
BLUE="\033[0;34m"
NOCOLOUR="\033[0m"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROPERTIES_FILE="$SCRIPT_DIR/../properties.conf"
CONFIG_FILE="$SCRIPT_DIR/configs/anti-detection.conf"

# Banner
echo -e "${BLUE}"
cat << "EOF"
╔════════════════════════════════════════════════════════╗
║     ANTI-DETECTION SYSTEM - CONTROL PANEL             ║
╚════════════════════════════════════════════════════════╝
EOF
echo -e "${NOCOLOUR}"

# Function to check current status
check_status() {
    local enabled_in_properties=false
    local enabled_in_config=false
    
    if [ -f "$PROPERTIES_FILE" ]; then
        if grep -q "^ENABLE_ANTI_DETECTION=true" "$PROPERTIES_FILE"; then
            enabled_in_properties=true
        fi
    fi
    
    if [ -f "$CONFIG_FILE" ]; then
        if grep -q "^ENABLE_ANTI_DETECTION=true" "$CONFIG_FILE"; then
            enabled_in_config=true
        fi
    fi
    
    echo -e "${YELLOW}Current Status:${NOCOLOUR}"
    echo -e "  properties.conf: $([ "$enabled_in_properties" = true ] && echo -e "${GREEN}ENABLED${NOCOLOUR}" || echo -e "${RED}DISABLED${NOCOLOUR}")"
    echo -e "  anti-detection.conf: $([ "$enabled_in_config" = true ] && echo -e "${GREEN}ENABLED${NOCOLOUR}" || echo -e "${RED}DISABLED${NOCOLOUR}")"
    echo ""
}

# Function to enable
enable_anti_detection() {
    echo -e "${GREEN}Enabling Anti-Detection System...${NOCOLOUR}"
    
    # Enable in properties.conf
    if [ -f "$PROPERTIES_FILE" ]; then
        sed -i 's/^ENABLE_ANTI_DETECTION=false/ENABLE_ANTI_DETECTION=true/' "$PROPERTIES_FILE"
        echo -e "${GREEN}✓ Enabled in properties.conf${NOCOLOUR}"
    else
        echo -e "${RED}✗ properties.conf not found${NOCOLOUR}"
    fi
    
    # Enable in anti-detection.conf
    if [ -f "$CONFIG_FILE" ]; then
        sed -i 's/^ENABLE_ANTI_DETECTION=false/ENABLE_ANTI_DETECTION=true/' "$CONFIG_FILE"
        sed -i 's/^ENABLE_ANTI_DETECTION=.*/ENABLE_ANTI_DETECTION=true/' "$CONFIG_FILE"
        echo -e "${GREEN}✓ Enabled in anti-detection.conf${NOCOLOUR}"
    else
        echo -e "${RED}✗ anti-detection.conf not found${NOCOLOUR}"
    fi
    
    echo ""
    echo -e "${GREEN}✓ Anti-Detection System ENABLED${NOCOLOUR}"
    echo -e "${YELLOW}Run 'sudo bash internetIncome.sh --start' to apply changes${NOCOLOUR}"
}

# Function to disable
disable_anti_detection() {
    echo -e "${YELLOW}Disabling Anti-Detection System...${NOCOLOUR}"
    
    # Disable in properties.conf
    if [ -f "$PROPERTIES_FILE" ]; then
        sed -i 's/^ENABLE_ANTI_DETECTION=true/ENABLE_ANTI_DETECTION=false/' "$PROPERTIES_FILE"
        echo -e "${YELLOW}✓ Disabled in properties.conf${NOCOLOUR}"
    fi
    
    # Disable in anti-detection.conf
    if [ -f "$CONFIG_FILE" ]; then
        sed -i 's/^ENABLE_ANTI_DETECTION=true/ENABLE_ANTI_DETECTION=false/' "$CONFIG_FILE"
        sed -i 's/^ENABLE_ANTI_DETECTION=.*/ENABLE_ANTI_DETECTION=false/' "$CONFIG_FILE"
        echo -e "${YELLOW}✓ Disabled in anti-detection.conf${NOCOLOUR}"
    fi
    
    echo ""
    echo -e "${YELLOW}✓ Anti-Detection System DISABLED${NOCOLOUR}"
    echo -e "${YELLOW}Changes will take effect on next run${NOCOLOUR}"
}

# Function to test
test_anti_detection() {
    echo -e "${BLUE}Testing Anti-Detection Configuration...${NOCOLOUR}"
    echo ""
    
    # Check syntax
    echo -e "${YELLOW}1. Checking script syntax...${NOCOLOUR}"
    if bash -n "$SCRIPT_DIR/anti-detection.sh" 2>/dev/null; then
        echo -e "${GREEN}✓ Main script syntax OK${NOCOLOUR}"
    else
        echo -e "${RED}✗ Syntax error in main script${NOCOLOUR}"
    fi
    
    # Check all sub-scripts
    local all_ok=true
    for script in "$SCRIPT_DIR/scripts"/*.sh; do
        if ! bash -n "$script" 2>/dev/null; then
            echo -e "${RED}✗ Syntax error in $(basename $script)${NOCOLOUR}"
            all_ok=false
        fi
    done
    
    if [ "$all_ok" = true ]; then
        echo -e "${GREEN}✓ All scripts syntax OK${NOCOLOUR}"
    fi
    
    echo ""
    echo -e "${YELLOW}2. Checking configuration files...${NOCOLOUR}"
    [ -f "$CONFIG_FILE" ] && echo -e "${GREEN}✓ anti-detection.conf exists${NOCOLOUR}" || echo -e "${RED}✗ anti-detection.conf missing${NOCOLOUR}"
    [ -f "$PROPERTIES_FILE" ] && echo -e "${GREEN}✓ properties.conf exists${NOCOLOUR}" || echo -e "${RED}✗ properties.conf missing${NOCOLOUR}"
    
    echo ""
    echo -e "${YELLOW}3. Checking script permissions...${NOCOLOUR}"
    [ -x "$SCRIPT_DIR/anti-detection.sh" ] && echo -e "${GREEN}✓ Main script executable${NOCOLOUR}" || echo -e "${RED}✗ Main script not executable${NOCOLOUR}"
    
    echo ""
    echo -e "${YELLOW}4. Checking dependencies...${NOCOLOUR}"
    command -v curl &> /dev/null && echo -e "${GREEN}✓ curl available${NOCOLOUR}" || echo -e "${YELLOW}⚠ curl not found (needed for IP geolocation)${NOCOLOUR}"
    command -v sysctl &> /dev/null && echo -e "${GREEN}✓ sysctl available${NOCOLOUR}" || echo -e "${YELLOW}⚠ sysctl not found (needed for TCP/IP spoofing)${NOCOLOUR}"
    
    echo ""
    echo -e "${GREEN}✓ Test complete${NOCOLOUR}"
}

# Function to show info
show_info() {
    echo -e "${BLUE}Anti-Detection System Information${NOCOLOUR}"
    echo ""
    echo -e "${YELLOW}What it does:${NOCOLOUR}"
    echo "  • Mimics Windows TCP/IP stack (changes TTL to 128)"
    echo "  • Hides Docker container indicators"
    echo "  • Synchronizes timezone with IP geolocation"
    echo "  • Generates browser fingerprint spoofing scripts"
    echo "  • Prevents WebRTC IP leaks"
    echo "  • Spoofs canvas and WebGL fingerprints"
    echo ""
    echo -e "${YELLOW}Effectiveness:${NOCOLOUR}"
    echo "  • With VPS IP: ~30-40% detection rate"
    echo "  • With Residential Proxy: ~5-10% detection rate"
    echo ""
    echo -e "${YELLOW}Documentation:${NOCOLOUR}"
    echo "  • Quick Start: anti-detection/QUICKSTART.md"
    echo "  • Full Docs: anti-detection/README.md"
    echo "  • Main README: ANTI_DETECTION.md"
    echo ""
}

# Main menu
case "$1" in
    --enable)
        check_status
        enable_anti_detection
        ;;
    --disable)
        check_status
        disable_anti_detection
        ;;
    --status)
        check_status
        ;;
    --test)
        test_anti_detection
        ;;
    --info)
        show_info
        ;;
    *)
        check_status
        echo -e "${YELLOW}Usage:${NOCOLOUR}"
        echo "  $0 --enable      Enable anti-detection system"
        echo "  $0 --disable     Disable anti-detection system"
        echo "  $0 --status      Show current status"
        echo "  $0 --test        Test configuration and scripts"
        echo "  $0 --info        Show information about the system"
        echo ""
        echo -e "${YELLOW}Quick Commands:${NOCOLOUR}"
        echo "  Enable:  ./anti-detection/control.sh --enable"
        echo "  Disable: ./anti-detection/control.sh --disable"
        echo ""
        ;;
esac
