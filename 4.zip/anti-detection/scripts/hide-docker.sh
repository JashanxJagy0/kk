#!/bin/bash

################################################################################
# Docker Detection Prevention Script
# Purpose: Hide Docker environment indicators and spoof hardware information
# This prevents detection of Docker containers through file system checks
################################################################################

# Colors for output
RED="\033[0;31m"
GREEN="\033[0;32m"
YELLOW="\033[0;33m"
NOCOLOUR="\033[0m"

# Load configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="$SCRIPT_DIR/../configs/anti-detection.conf"

if [ -f "$CONFIG_FILE" ]; then
    source "$CONFIG_FILE"
else
    echo -e "${RED}Configuration file not found: $CONFIG_FILE${NOCOLOUR}"
    exit 1
fi

if [ "$ENABLE_ANTI_DETECTION" != "true" ]; then
    echo -e "${YELLOW}Anti-detection system is disabled in configuration${NOCOLOUR}"
    exit 0
fi

echo -e "${GREEN}=== Docker Detection Prevention ===${NOCOLOUR}"

# Function to hide Docker environment file
hide_docker_env() {
    if [ "$HIDE_DOCKER_ENV" = "true" ]; then
        echo -e "${GREEN}Hiding Docker environment indicators...${NOCOLOUR}"
        
        # Check if .dockerenv exists
        if [ -f "/.dockerenv" ]; then
            if [ -w "/.dockerenv" ] || [ "$EUID" -eq 0 ] || sudo -n true 2>/dev/null; then
                # Try to remove or hide .dockerenv
                if rm -f "/.dockerenv" 2>/dev/null || sudo rm -f "/.dockerenv" 2>/dev/null; then
                    echo -e "${GREEN}✓ Removed /.dockerenv${NOCOLOUR}"
                else
                    echo -e "${YELLOW}⚠ Could not remove /.dockerenv (permission denied)${NOCOLOUR}"
                fi
            else
                echo -e "${YELLOW}⚠ Cannot modify /.dockerenv (need root)${NOCOLOUR}"
            fi
        else
            echo -e "${GREEN}✓ /.dockerenv not found (already hidden)${NOCOLOUR}"
        fi
        
        # Try to hide container ID from /proc/self/cgroup
        if [ -f "/proc/self/cgroup" ] && [ "$HIDE_CGROUPS" = "true" ]; then
            if grep -q docker /proc/self/cgroup 2>/dev/null; then
                echo -e "${YELLOW}⚠ Docker/container indicators found in cgroups${NOCOLOUR}"
                echo -e "${YELLOW}  Note: cgroups are read-only and cannot be modified at runtime${NOCOLOUR}"
                echo -e "${YELLOW}  Consider running with '--security-opt apparmor=unconfined' or custom cgroup namespace${NOCOLOUR}"
            else
                echo -e "${GREEN}✓ No Docker indicators in cgroups${NOCOLOUR}"
            fi
        fi
    fi
}

# Function to spoof CPU information
spoof_cpuinfo() {
    if [ "$SPOOF_PROC_CPUINFO" = "true" ]; then
        echo -e "${GREEN}Spoofing CPU information...${NOCOLOUR}"
        
        # Create fake cpuinfo
        FAKE_CPUINFO="/tmp/cpuinfo"
        
        cat > "$FAKE_CPUINFO" << 'EOF'
processor	: 0
vendor_id	: GenuineIntel
cpu family	: 6
model		: 158
model name	: Intel(R) Core(TM) i5-8250U CPU @ 1.60GHz
stepping	: 10
microcode	: 0xb4
cpu MHz		: 1800.000
cache size	: 6144 KB
physical id	: 0
siblings	: 4
core id		: 0
cpu cores	: 4
apicid		: 0
initial apicid	: 0
fpu		: yes
fpu_exception	: yes
cpuid level	: 22
wp		: yes
flags		: fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush dts acpi mmx fxsr sse sse2 ss ht tm pbe syscall nx pdpe1gb rdtscp lm constant_tsc art arch_perfmon pebs bts rep_good nopl xtopology nonstop_tsc cpuid aperfmperf tsc_known_freq pni pclmulqdq dtes64 monitor ds_cpl vmx est tm2 ssse3 sdbg fma cx16 xtpr pdcm pcid sse4_1 sse4_2 x2apic movbe popcnt tsc_deadline_timer aes xsave avx f16c rdrand lahf_lm abm 3dnowprefetch cpuid_fault epb invpcid_single pti ssbd ibrs ibpb stibp tpr_shadow vnmi flexpriority ept vpid ept_ad fsgsbase tsc_adjust bmi1 avx2 smep bmi2 erms invpcid mpx rdseed adx smap clflushopt intel_pt xsaveopt xsavec xgetbv1 xsaves dtherm ida arat pln pts hwp hwp_notify hwp_act_window hwp_epp md_clear flush_l1d
bugs		: cpu_meltdown spectre_v1 spectre_v2 spec_store_bypass l1tf mds swapgs itlb_multihit srbds
bogomips	: 3600.00
clflush size	: 64
cache_alignment	: 64
address sizes	: 39 bits physical, 48 bits virtual
power management:

processor	: 1
vendor_id	: GenuineIntel
cpu family	: 6
model		: 158
model name	: Intel(R) Core(TM) i5-8250U CPU @ 1.60GHz
stepping	: 10
microcode	: 0xb4
cpu MHz		: 1800.000
cache size	: 6144 KB
physical id	: 0
siblings	: 4
core id		: 1
cpu cores	: 4
apicid		: 2
initial apicid	: 2
fpu		: yes
fpu_exception	: yes
cpuid level	: 22
wp		: yes
flags		: fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush dts acpi mmx fxsr sse sse2 ss ht tm pbe syscall nx pdpe1gb rdtscp lm constant_tsc art arch_perfmon pebs bts rep_good nopl xtopology nonstop_tsc cpuid aperfmperf tsc_known_freq pni pclmulqdq dtes64 monitor ds_cpl vmx est tm2 ssse3 sdbg fma cx16 xtpr pdcm pcid sse4_1 sse4_2 x2apic movbe popcnt tsc_deadline_timer aes xsave avx f16c rdrand lahf_lm abm 3dnowprefetch cpuid_fault epb invpcid_single pti ssbd ibrs ibpb stibp tpr_shadow vnmi flexpriority ept vpid ept_ad fsgsbase tsc_adjust bmi1 avx2 smep bmi2 erms invpcid mpx rdseed adx smap clflushopt intel_pt xsaveopt xsavec xgetbv1 xsaves dtherm ida arat pln pts hwp hwp_notify hwp_act_window hwp_epp md_clear flush_l1d
bugs		: cpu_meltdown spectre_v1 spectre_v2 spec_store_bypass l1tf mds swapgs itlb_multihit srbds
bogomips	: 3600.00
clflush size	: 64
cache_alignment	: 64
address sizes	: 39 bits physical, 48 bits virtual
power management:

processor	: 2
vendor_id	: GenuineIntel
cpu family	: 6
model		: 158
model name	: Intel(R) Core(TM) i5-8250U CPU @ 1.60GHz
stepping	: 10
microcode	: 0xb4
cpu MHz		: 1800.000
cache size	: 6144 KB
physical id	: 0
siblings	: 4
core id		: 2
cpu cores	: 4
apicid		: 4
initial apicid	: 4
fpu		: yes
fpu_exception	: yes
cpuid level	: 22
wp		: yes
flags		: fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush dts acpi mmx fxsr sse sse2 ss ht tm pbe syscall nx pdpe1gb rdtscp lm constant_tsc art arch_perfmon pebs bts rep_good nopl xtopology nonstop_tsc cpuid aperfmperf tsc_known_freq pni pclmulqdq dtes64 monitor ds_cpl vmx est tm2 ssse3 sdbg fma cx16 xtpr pdcm pcid sse4_1 sse4_2 x2apic movbe popcnt tsc_deadline_timer aes xsave avx f16c rdrand lahf_lm abm 3dnowprefetch cpuid_fault epb invpcid_single pti ssbd ibrs ibpb stibp tpr_shadow vnmi flexpriority ept vpid ept_ad fsgsbase tsc_adjust bmi1 avx2 smep bmi2 erms invpcid mpx rdseed adx smap clflushopt intel_pt xsaveopt xsavec xgetbv1 xsaves dtherm ida arat pln pts hwp hwp_notify hwp_act_window hwp_epp md_clear flush_l1d
bugs		: cpu_meltdown spectre_v1 spectre_v2 spec_store_bypass l1tf mds swapgs itlb_multihit srbds
bogomips	: 3600.00
clflush size	: 64
cache_alignment	: 64
address sizes	: 39 bits physical, 48 bits virtual
power management:

processor	: 3
vendor_id	: GenuineIntel
cpu family	: 6
model		: 158
model name	: Intel(R) Core(TM) i5-8250U CPU @ 1.60GHz
stepping	: 10
microcode	: 0xb4
cpu MHz		: 1800.000
cache size	: 6144 KB
physical id	: 0
siblings	: 4
core id		: 3
cpu cores	: 4
apicid		: 6
initial apicid	: 6
fpu		: yes
fpu_exception	: yes
cpuid level	: 22
wp		: yes
flags		: fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush dts acpi mmx fxsr sse sse2 ss ht tm pbe syscall nx pdpe1gb rdtscp lm constant_tsc art arch_perfmon pebs bts rep_good nopl xtopology nonstop_tsc cpuid aperfmperf tsc_known_freq pni pclmulqdq dtes64 monitor ds_cpl vmx est tm2 ssse3 sdbg fma cx16 xtpr pdcm pcid sse4_1 sse4_2 x2apic movbe popcnt tsc_deadline_timer aes xsave avx f16c rdrand lahf_lm abm 3dnowprefetch cpuid_fault epb invpcid_single pti ssbd ibrs ibpb stibp tpr_shadow vnmi flexpriority ept vpid ept_ad fsgsbase tsc_adjust bmi1 avx2 smep bmi2 erms invpcid mpx rdseed adx smap clflushopt intel_pt xsaveopt xsavec xgetbv1 xsaves dtherm ida arat pln pts hwp hwp_notify hwp_act_window hwp_epp md_clear flush_l1d
bugs		: cpu_meltdown spectre_v1 spectre_v2 spec_store_bypass l1tf mds swapgs itlb_multihit srbds
bogomips	: 3600.00
clflush size	: 64
cache_alignment	: 64
address sizes	: 39 bits physical, 48 bits virtual
power management:

EOF
        echo -e "${GREEN}✓ Created fake cpuinfo${NOCOLOUR}"
        echo -e "${YELLOW}  Note: To use this, mount it in Docker with: -v /tmp/cpuinfo:/proc/cpuinfo:ro${NOCOLOUR}"
    fi
}

# Execute functions
hide_docker_env
spoof_cpuinfo

echo -e "${GREEN}=== Docker Detection Prevention Complete ===${NOCOLOUR}"

if [ "$DEBUG_MODE" = "true" ]; then
    echo -e "${YELLOW}Debug: Checking for Docker indicators:${NOCOLOUR}"
    echo -e "  /.dockerenv: $([ -f /.dockerenv ] && echo 'EXISTS' || echo 'NOT FOUND')"
    echo -e "  Docker in cgroups: $(grep -q docker /proc/self/cgroup 2>/dev/null && echo 'FOUND' || echo 'NOT FOUND')"
fi
